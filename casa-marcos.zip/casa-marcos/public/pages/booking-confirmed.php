<?php
// booking-confirmed.php

// Optionally, you can add a header to control caching
header("Cache-Control: no-cache, must-revalidate"); // Prevents caching
header("Expires: Sat, 26 Jul 1997 05:00:00 GMT"); // Past date

echo "<h1>Booking Confirmed!</h1>";
echo "<p>Thank you for your booking!</p>";
echo "<p>We will contact you shortly.</p>";
?>